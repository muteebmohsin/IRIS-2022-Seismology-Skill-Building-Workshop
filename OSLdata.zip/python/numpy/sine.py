# sine wave plot tool
import numpy as np
import matplotlib.pyplot as plt
f = 0.5 # frequency of sine wave
A = 5 # maximun amplitude of sine wave
x = np.arange(-6.28, 6.28, 0.01)
y = A * np.tan( f * x )
plt.plot(x,y)
plt.xlabel('angle')
plt.ylabel('Amplitude')
plt.show()
