import os
os.system('echo "Hello from the other side"')
cmd = 'ls-lt'
os.system(cmd)
